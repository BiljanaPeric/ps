﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class FromaKlijent : Form
    {
        Komunikacija k;
        public FromaKlijent()
        {
            InitializeComponent();
        }

        private void FromaKlijent_Load(object sender, EventArgs e)
        {
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "POVEZAN!";
            }
        }
    }
}
