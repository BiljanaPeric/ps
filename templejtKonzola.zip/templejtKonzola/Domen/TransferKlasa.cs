﻿using System;

namespace Domen
{
    public enum Operacije { kraj = 1 };
    [Serializable]
    public class TransferKlasa
    {
        public Operacije Operacija;
        public Object TransferObjekat;
        public Object Rezultat;


    }
}
