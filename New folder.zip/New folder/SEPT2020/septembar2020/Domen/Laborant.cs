﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domen
{
    [Serializable]
   public  class Laborant
    {

        public override string ToString()
        {
            return ime + " " + prezime;        }
        int laborantID;
        string ime;
        string prezime;
        string kotisnickoIme;
        string lozinka;
        Laboratorija laboratorija;

        public int LaborantID { get => laborantID; set => laborantID = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public string KotisnickoIme { get => kotisnickoIme; set => kotisnickoIme = value; }
        public string Lozinka { get => lozinka; set => lozinka = value; }
        public Laboratorija Laboratorija { get => laboratorija; set => laboratorija = value; }
    }
}
