﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domen
{
    [Serializable]
        public  class Laboratorija
    {
        public override string ToString()
        {
            return naziv;
        }

        int laboratorijaID;
        string naziv;
        int dnevniKapacitetTestova;
        string grad;

        public int LaboratorijaID { get => laboratorijaID; set => laboratorijaID = value; }
        public string Naziv { get => naziv; set => naziv = value; }
        public int DnevniKapacitetTestova { get => dnevniKapacitetTestova; set => dnevniKapacitetTestova = value; }
        public string Grad { get => grad; set => grad = value; }
    }
}
