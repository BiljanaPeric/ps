﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domen
{
   // public enum Status { Neobradjen, Obradjen};
   [Serializable]
  public  class Zahtev
    {
        int zahtevID;
        DateTime datumIVremeTestiranja;
        bool hitno;
        string tip;
        string rezultat;
        DateTime datumIVremeRezultata;
        string napomena;
        string status;
        OsiguranoLice osigLice;
        Laborant laborant;
        Laboratorija laboratorija;

        public int ZahtevID { get => zahtevID; set => zahtevID = value; }
        public DateTime DatumIVremeTestiranja { get => datumIVremeTestiranja; set => datumIVremeTestiranja = value; }
        public bool Hitno { get => hitno; set => hitno = value; }
        public string Tip { get => tip; set => tip = value; }
        public string Rezultat { get => rezultat; set => rezultat = value; }
        public DateTime DatumIVremeRezultata { get => datumIVremeRezultata; set => datumIVremeRezultata = value; }
        public string Napomena { get => napomena; set => napomena = value; }
        public string Status { get => status; set => status = value; }
        public OsiguranoLice OsigLice { get => osigLice; set => osigLice = value; }
        public Laborant Laborant { get => laborant; set => laborant = value; }
        public Laboratorija Laboratorija { get => laboratorija; set => laboratorija = value; }
    }
}
