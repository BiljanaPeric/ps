﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domen
{
    [Serializable]
    public class OsiguranoLice
    {
        public override string ToString()
        {
            return ime + " " + prezime;
        }
        int osiguranoLiceID;
        string ime;
        string prezime;
       string lbo;
        string krvnaGrupa;

        public int OsiguranoLiceID { get => osiguranoLiceID; set => osiguranoLiceID = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
       
        public string KrvnaGrupa { get => krvnaGrupa; set => krvnaGrupa = value; }
        public string Lbo { get => lbo; set => lbo = value; }
    }
}
