﻿using System;

namespace Domen
{
    public enum Operacije { kraj = 1, Login = 2, VratiZahteve = 3, SacuvajIzmene = 4 };
    [Serializable]
    public class TransferKlasa
    {
        public Operacije Operacija;
        public Object TransferObjekat;
        public Object Rezultat;


    }
}
