﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domen;
using System.Data;
using System.Data.SqlClient;
namespace ServerKonzola
{
    public class Broker
    {

        SqlConnection konekcija;
        SqlTransaction transakcija;
        SqlCommand komanda;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=sept2020;Integrated Security=True");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        static Broker instanca;

        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }


        public Laborant Login(Laborant l)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Laborant l inner join Laboratorija la on l.LaboratorijaID=la.LaboratorijaID where l.KorisnickoIme = '" + l.KotisnickoIme + "' and l.Lozinka = '" + l.Lozinka + "'";
                SqlDataReader citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    l.LaborantID = citac.GetInt32(0);
                    l.Ime = citac.GetString(1);
                    l.Prezime = citac.GetString(2);
                    l.Laboratorija = new Laboratorija();
                    l.Laboratorija.LaboratorijaID = citac.GetInt32(5);
                    l.Laboratorija.Naziv = citac.GetString(7);
                    l.Laboratorija.DnevniKapacitetTestova = citac.GetInt32(8);
                    l.Laboratorija.Grad = citac.GetString(9);

                    citac.Close();
                    return l;

                }
                citac.Close();
                return null;

            }
            catch (Exception)
            {

                return null;
            }
            finally { if (konekcija != null) konekcija.Close(); }

        }
        public List<Zahtev> vratiSveZahteve(Laboratorija la)
        {
            List<Zahtev> listaZahteva = new List<Zahtev>();

            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Zahtev z join OsiguranoLice l on z.OsiguranoLiceID =l.OsiguranoLiceID where z.LaboratorijaID =" + la.LaboratorijaID + " and z.Status ='Neobradjen' ";
                SqlDataReader citac = komanda.ExecuteReader();

                while (citac.Read())
                {
                    Zahtev z = new Zahtev();
                    z.ZahtevID = citac.GetInt32(0);
                    z.DatumIVremeTestiranja = citac.GetDateTime(1);
                    z.Hitno = citac.GetBoolean(2);
                    z.Status = citac.GetString(7);
                    z.OsigLice = new OsiguranoLice();
                    z.Laboratorija = la;
                    z.OsigLice.OsiguranoLiceID = citac.GetInt32(11);
                    z.OsigLice.Ime = citac.GetString(12);
                    z.OsigLice.Prezime = citac.GetString(13);
                    z.OsigLice.Lbo = citac.GetString(14);
                    z.OsigLice.KrvnaGrupa = citac.GetString(15);
                    listaZahteva.Add(z);

                }

                citac.Close();
                return listaZahteva;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }

        }

        public bool SacuvajIzmene(List<Zahtev> lista)
        {
            try
            {

                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);

                foreach (Zahtev z in lista)
                {
                    if (z.Laborant != null)
                    {
                        komanda.CommandText = "Update Zahtev set Tip ='" + z.Tip + "', Rezultat ='" + z.Rezultat + "',DatumVremeRezultata ='" + z.DatumIVremeRezultata.ToString("yyyy-MM-dd HH:mm") + "', Napomena ='" + z.Napomena + "', Status = '" + z.Status + "' , LaborantID =" + z.Laborant.LaborantID + " where ZahtevID = " + z.ZahtevID + "";
                        komanda.ExecuteNonQuery();
                    }

                }
                transakcija.Commit();
                return true;
            }

            catch (Exception)
            {
                transakcija.Rollback();
                return false;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }


    }
}
