﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class FromaKlijent : Form
    {
        BindingList<Zahtev> listaZahteva;
        Komunikacija k;
        Laborant l;

        public FromaKlijent()
        {

        }

        public FromaKlijent(Komunikacija k, Laborant l)
        {
            InitializeComponent();
            this.k = k;
            this.l = l;
        }

        private void FromaKlijent_Load(object sender, EventArgs e)
        {

            try
            {
                listaZahteva = new BindingList<Zahtev>(k.vratiZahteve(l.Laboratorija));
                gridGlavnaForma.DataSource = listaZahteva;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnIzmeni_Click(object sender, EventArgs e)
        {
            try
            {
                Zahtev z = gridGlavnaForma.CurrentRow.DataBoundItem as Zahtev;
                new Izmena(z, k, l).ShowDialog();
                gridGlavnaForma.Refresh();

            }
            catch (Exception)
            {

                throw;
            }

        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {
            if (k.sacuvajIzmene(new List<Zahtev>(listaZahteva)))
            {
                MessageBox.Show("Izmene su uspesno sacuvane!");

            }
            else
            {
                MessageBox.Show("Izmene nisu sacuvane!");
            }
        }
    }
}

