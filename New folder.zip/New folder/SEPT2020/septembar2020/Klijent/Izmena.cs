﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class Izmena : Form
    {
        private Komunikacija k;
        private Laborant l;
        private Zahtev z;
        public Izmena()
        {
            
        }

        public Izmena(Zahtev z, Komunikacija k, Laborant l)
        {
           
            this.z = z;
            this.k = k;
            this.l = l;
            InitializeComponent();

        }

        private void Izmena_Load(object sender, EventArgs e)
        {

        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {

            z.Tip = cmbtip.SelectedItem.ToString();

            if(string.IsNullOrEmpty(z.Tip))
            {
                MessageBox.Show("Niste odabrali tip");
                return;
            }
            z.Rezultat = cmbrezultat.SelectedItem.ToString();
            if(string.IsNullOrEmpty(z.Rezultat))
            { MessageBox.Show("Niste odabrali rezultat"); return; }

            z.Status = cmbstatus.SelectedItem.ToString();
            if (string.IsNullOrEmpty(z.Status))
            { MessageBox.Show("Niste odabrali status"); return; }
            z.Laborant = l;

            z.Napomena = txtNapomena.Text;
            if (string.IsNullOrEmpty(z.Status))
            { MessageBox.Show("Niste napisali napomenu"); return;
            }

            z.DatumIVremeRezultata = DateTime.Now;
            this.Close();

        }

        private void cmbtip_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
