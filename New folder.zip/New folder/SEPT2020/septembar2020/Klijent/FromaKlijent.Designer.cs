﻿namespace Klijent
{
    partial class FromaKlijent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gridGlavnaForma = new System.Windows.Forms.DataGridView();
            this.btnIzmeni = new System.Windows.Forms.Button();
            this.btnSacuvaj = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridGlavnaForma)).BeginInit();
            this.SuspendLayout();
            // 
            // gridGlavnaForma
            // 
            this.gridGlavnaForma.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.gridGlavnaForma.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridGlavnaForma.Location = new System.Drawing.Point(12, 25);
            this.gridGlavnaForma.Name = "gridGlavnaForma";
            this.gridGlavnaForma.Size = new System.Drawing.Size(809, 188);
            this.gridGlavnaForma.TabIndex = 0;
            // 
            // btnIzmeni
            // 
            this.btnIzmeni.Location = new System.Drawing.Point(221, 219);
            this.btnIzmeni.Name = "btnIzmeni";
            this.btnIzmeni.Size = new System.Drawing.Size(363, 44);
            this.btnIzmeni.TabIndex = 1;
            this.btnIzmeni.Text = "Izmeni";
            this.btnIzmeni.UseVisualStyleBackColor = true;
            this.btnIzmeni.Click += new System.EventHandler(this.btnIzmeni_Click);
            // 
            // btnSacuvaj
            // 
            this.btnSacuvaj.Location = new System.Drawing.Point(221, 281);
            this.btnSacuvaj.Name = "btnSacuvaj";
            this.btnSacuvaj.Size = new System.Drawing.Size(363, 38);
            this.btnSacuvaj.TabIndex = 2;
            this.btnSacuvaj.Text = "Sacuvaj";
            this.btnSacuvaj.UseVisualStyleBackColor = true;
            this.btnSacuvaj.Click += new System.EventHandler(this.btnSacuvaj_Click);
            // 
            // FromaKlijent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(833, 346);
            this.Controls.Add(this.btnSacuvaj);
            this.Controls.Add(this.btnIzmeni);
            this.Controls.Add(this.gridGlavnaForma);
            this.Name = "FromaKlijent";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FromaKlijent_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridGlavnaForma)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gridGlavnaForma;
        private System.Windows.Forms.Button btnIzmeni;
        private System.Windows.Forms.Button btnSacuvaj;
    }
}

