﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class OsiguranoLice
    {
        public override string ToString()
        {
            return ime+" "+prezime;
        }

        int id;
        string ime;
        string prezime;
        string lbo;
        string krvnaGrupa;

        public int Id { get => id; set => id = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public string Lbo { get => lbo; set => lbo = value; }
        public string KrvnaGrupa { get => krvnaGrupa; set => krvnaGrupa = value; }
      
    }
}
