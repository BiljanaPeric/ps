﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using Domen;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void poveziSe()
        {
            konekcija = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=sept2020;Integrated Security=True");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            poveziSe();
        }

        static Broker instanca;
        public static Broker DajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }



        public Laborant Login(Laborant l)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Laborant l inner join Laboratorija la on l.LaboratorijaID=la.LaboratorijaID where l.KorisnickoIme='"+l.KorisnickoIme+"' and l.Lozinka='"+l.Lozinka+"'";
                SqlDataReader citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    l.Id = citac.GetInt32(0);
                    l.Ime = citac.GetString(1);
                    l.Prezime = citac.GetString(2);
                    l.Laboratorija = new Laboratorija();
                    l.Laboratorija.Id = citac.GetInt32(6);
                    l.Laboratorija.Naziv = citac.GetString(7);
                    l.Laboratorija.Kapacitet = citac.GetInt32(8);
                    l.Laboratorija.Grad = citac.GetString(9);

                    citac.Close();
                    return l;

                }
                citac.Close();
                return null;
                
            }
            catch (Exception)
            {

                return null;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }


        public List<Zahtev> vratiNeobradjeneZahteve(Laboratorija l)
        {
            List<Zahtev> lista = new List<Zahtev>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Zahtev z inner join OsiguranoLice ol on z.OsiguranoLiceID=ol.OsiguranoLiceID where z.LaboratorijaID="+l.Id+" and Status='Neobradjen'";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Zahtev z = new Zahtev();
                    z.Id = citac.GetInt32(0);
                    z.DatumTestiranja = citac.GetDateTime(1);
                    z.Hitno = citac.GetBoolean(2);
                    z.Status = citac.GetString(7);
                    z.OsiguranoLice = new OsiguranoLice();
                    z.Laboratorija = l;
                    z.OsiguranoLice.Id = citac.GetInt32(11);
                    z.OsiguranoLice.Ime = citac.GetString(12);
                    z.OsiguranoLice.Prezime = citac.GetString(13);
                    z.OsiguranoLice.Lbo = citac.GetString(14);
                    z.OsiguranoLice.KrvnaGrupa = citac.GetString(15);


                    lista.Add(z);
                }
                citac.Close();
                return lista;

            }
            catch (Exception)
            {

                return null;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }



        public bool SacuvajIzmene(List<Zahtev> lista)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);

                foreach (Zahtev z in lista)
                {
                    if (z.Laborant != null)
                    {
                        komanda.CommandText = "Update Zahtev set Tip='" + z.Tip + "', Rezultat='" + z.Rezultat + "', DatumVremeRezultata='" + z.DatumRezultata.ToString("yyyy-MM-dd HH:mm") + "', Status='" + z.Status + "', LaborantID='" + z.Laborant.Id + "' where ZahtevID=" + z.Id + "";

                        komanda.ExecuteNonQuery();
                    }
                }

                transakcija.Commit();
                return true;
                

            }
            catch (Exception)
            {
                transakcija.Rollback();
                return false;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }


        public List<Laboratorija> VratiSveLaboratorije()
        {
            List<Laboratorija> lista = new List<Laboratorija>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Laboratorija";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                   
                    Laboratorija l = new Laboratorija();
                    l.Id = citac.GetInt32(0);
                    l.Naziv = citac.GetString(1);
                    l.Kapacitet = citac.GetInt32(2);
                    l.Grad = citac.GetString(3);

                    lista.Add(l);

                }
                citac.Close();
                return lista;

            }
            catch (Exception)
            {

                return null;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public List<ServerObjekat> VratiZaServer(string kriterijum)
        {
            List<ServerObjekat> lista = new List<ServerObjekat>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select  z.Tip, sum(case when z.Rezultat='Pozitivan' then 1 else 0 end), sum(case when z.Rezultat='Pozitivan' then 0 else 1 end)  from Zahtev z where z.Status='Obradjen' "+kriterijum+" group by z.Tip";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {

                    ServerObjekat s = new ServerObjekat();
                    
                    s.Tip= citac.GetString(0);
                    try
                    {
                        s.BrPozitivnih = Convert.ToInt32(citac.GetValue(1));
                        s.BrNegativnih = Convert.ToInt32(citac.GetValue(2));
                    }
                    catch (Exception)
                    {

                       
                    }

                    lista.Add(s);

                }
                citac.Close();
                return lista;

            }
            catch (Exception)
            {

                return null;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

    }
}
