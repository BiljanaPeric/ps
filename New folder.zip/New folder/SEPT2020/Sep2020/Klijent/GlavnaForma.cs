﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class GlavnaForma : Form
    {
        Komunikacija k;
        Laborant l;
        BindingList<Zahtev> listaZahteva;
        public GlavnaForma(Komunikacija k, Laborant l)
        {
            this.k = k;
            this.l = l;
            InitializeComponent();
        }

        private void GlavnaForma_FormClosed(object sender, FormClosedEventArgs e)
        {
            k.Kraj();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Zahtev z = dataGridView1.CurrentRow.DataBoundItem as Zahtev;

                new IzmenaZahteva(z, k, l).ShowDialog();
                dataGridView1.Refresh();
            }
            catch (Exception)
            {

               
            }
        }

        private void GlavnaForma_Load(object sender, EventArgs e)
        {
            try
            {
                listaZahteva = new BindingList<Zahtev>(k.VratiZahteve(l.Laboratorija));
                dataGridView1.DataSource = listaZahteva;
            }
            catch (Exception)
            {

               
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (k.ZapamtiIzmene(new List<Zahtev>(listaZahteva)))
            {
                MessageBox.Show("Izmene su uspesno sacuvane!");
                GlavnaForma_Load(sender, e);
            }
            else
            {
                MessageBox.Show("Izmene nisu sacuvane!");
            }
        }
    }
}
