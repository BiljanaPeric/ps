﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class IzmenaZahteva : Form
    {
        private Zahtev z;
        private Komunikacija k;
        private Laborant l;
        List<string> listaTipova;
        List<string> listaRezultata;
        List<string> listaStatusa;


        void postaviVrednosti()
        {
            listaRezultata = new List<string>();
            listaRezultata.Add("Pozitivan");
            listaRezultata.Add("Negativan");

            listaStatusa = new List<string>();
            listaStatusa.Add("Neobradjen");
            listaStatusa.Add("Obradjen");
            listaStatusa.Add("Nedostaju podaci");

            listaTipova = new List<string>();
            listaTipova.Add("PCR");
            listaTipova.Add("Seroloski");
            listaTipova.Add("Antitela");
        }

        public IzmenaZahteva(Zahtev z, Komunikacija k, Laborant l)
        {
            this.z = z;
            this.k = k;
            this.l = l;
            InitializeComponent();
        }

        private void IzmenaZahteva_Load(object sender, EventArgs e)
        {
            postaviVrednosti();

            cmbRezultat.DataSource = listaRezultata;
            cmbStatus.DataSource = listaStatusa;
            cmbTip.DataSource = listaTipova;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            z.Tip = cmbTip.SelectedItem.ToString();
            if (String.IsNullOrEmpty(z.Tip))
            {
                MessageBox.Show("Niste odabrali tip!");
                return;
            }
            z.Rezultat = cmbRezultat.SelectedItem.ToString();
            if (String.IsNullOrEmpty(z.Rezultat))
            {
                MessageBox.Show("Niste odabrali rezultat!");
                return;
            }
            z.Status = cmbStatus.SelectedItem.ToString();
            if (String.IsNullOrEmpty(z.Status))
            {
                MessageBox.Show("Niste odabrali status!");
                return;
            }
            z.Laborant = l;
            z.Napomena = txtNapomena.Text;
            if (String.IsNullOrEmpty(z.Napomena))
            {
                MessageBox.Show("Niste uneli napomenu!");
                return;
            }
            z.DatumRezultata = DateTime.Now;
            this.Close();
        }

        private void cmbTip_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
