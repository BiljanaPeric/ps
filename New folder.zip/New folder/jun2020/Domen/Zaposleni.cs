﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Domen
{
    [Serializable]
    public class Zaposleni
    {
        int zaposleniID;
        string ime;
        string prezime;
        string JBMG;
        string ziroRacun;
        double iznos;
        Kompanija kompanija;
        Banka banka;
        [Browsable(false)]
        public int ZaposleniID { get => zaposleniID; set => zaposleniID = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public string JBMG1 { get => JBMG; set => JBMG = value; }
        public string ZiroRacun { get => ziroRacun; set => ziroRacun = value; }
        [Browsable(false)]
        public double Iznos { get => iznos; set => iznos = value; }
        [Browsable(false)]
        public Kompanija Kompanija { get => kompanija; set => kompanija = value; }
        public Banka Banka { get => banka; set => banka = value; }
    }
}
