﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domen
{
    [Serializable]

    public class Kompanija
    {
        int kompanijaID;
        string naziv;
        string tip;
        bool pdvObveznik;
        string maticni;
        DateTime datum;
        int brojZaposlenih;
        Korisnik korisnik;

        public int KompanijaID { get => kompanijaID; set => kompanijaID = value; }
        public string Naziv { get => naziv; set => naziv = value; }
        public string Tip { get => tip; set => tip = value; }
     
        public string Maticni { get => maticni; set => maticni = value; }
        public DateTime Datum { get => datum; set => datum = value; }
        public int BrojZaposlenih { get => brojZaposlenih; set => brojZaposlenih = value; }
        public Korisnik Korisnik { get => korisnik; set => korisnik = value; }
        public bool PdvObveznik { get => pdvObveznik; set => pdvObveznik = value; }
    }
}
