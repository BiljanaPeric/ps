﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domen
{

    [Serializable]
     public class Banka
    {
        int bankaID;
        string naziv;
        string adresa;
        int jedinstveniBroj;
        public override string ToString()
        {
            return naziv;
        }
        public int BankaID { get => bankaID; set => bankaID = value; }
        public string Naziv { get => naziv; set => naziv = value; }
        public string Adresa { get => adresa; set => adresa = value; }
        public int JedinstveniBroj { get => jedinstveniBroj; set => jedinstveniBroj = value; }
    }
}
