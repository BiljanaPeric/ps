﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domen;
using System.Data;
using System.Data.SqlClient;
namespace ServerKonzola
{
    public class Broker
    {

        SqlConnection konekcija;
        SqlTransaction transakcija;
        SqlCommand komanda;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=jun2020;Integrated Security=True");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        static Broker instanca;

        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        public Korisnik login(Korisnik k)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Korisnik where KorisnickoIme ='" + k.KorisnickoIme + "' and Lozinka ='" + k.Lozinka + "'";
                SqlDataReader citac = komanda.ExecuteReader();

                if (citac.Read())
                {
                    k.KorisnikID = citac.GetInt32(0);
                    k.Ime = citac.GetString(1);
                    k.Prezime = citac.GetString(2);
                    citac.Close();
                    return k;

                }
                citac.Close();
                return null;

            }
            catch (Exception)
            {

                return null;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<Banka> vratiBAnke()
        {
            List<Banka> lista = new List<Banka>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Banka";
                SqlDataReader citac = komanda.ExecuteReader();

                while (citac.Read())
                {
                    Banka b = new Banka();
                    b.BankaID = citac.GetInt32(0);
                    b.Naziv = citac.GetString(1);
                    b.Adresa = citac.GetString(2);
                    b.JedinstveniBroj = citac.GetInt32(3);
                    lista.Add(b);

                }
                citac.Close();
                return lista;

            }
            catch (Exception)
            {

                return null;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }


        //VALIDACIJEEEEEEEEEEEEEEEEEEEEEEEE
        public List<string> vratiMaticni()
        {
            List<string> lista = new List<string>();

            try
            {
                komanda.CommandText = "Select MaticniBroj from Kompanija";
                SqlDataReader citac = komanda.ExecuteReader();

                while (citac.Read())
                {
                    lista.Add(citac.GetString(0));
                }
                citac.Close();
                return lista;
            }

            catch
            {
                return null;
            }
        }


        public int vratiSifruKOmpanije()
        {
            // int sifra;
            try
            {
                komanda.CommandText = "Select max(KompanijaID) from Kompanija";
                try
                {
                    int sifra = Convert.ToInt32(komanda.ExecuteScalar());
                    return sifra + 1;
                }
                catch (Exception)
                {

                    return 1;
                }
            }
            catch (Exception)
            {
                throw;

                // System.Windows.Forms.MessageBox.Show("Greska");
            }
        }
        public int vratiSifruZaposlenog()
        {
            // int sifra;
            try
            {
                komanda.CommandText = "Select max(ZaposleniID) from Zaposleni";
                try
                {
                    int sifra = Convert.ToInt32(komanda.ExecuteScalar());
                    return sifra + 1;
                }
                catch (Exception)
                {

                    return 1;
                }
            }
            catch (Exception)
            {
                throw;

                // System.Windows.Forms.MessageBox.Show("Greska");
            }
        }
        public int getBIt(bool b)
        {
            if (b) return 1;
            return 0;
        }
        public bool sacuvaj(Kompanija k)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);
                k.KompanijaID = vratiSifruKOmpanije();

                foreach(string s in vratiMaticni())
                {
                    if (s == k.Maticni)
                    {
                        System.Windows.Forms.MessageBox.Show("Kompanija sa tim maticnim vec postoji");
                        return false;
                    }
                }

                komanda.CommandText = "Insert into Kompanija values(" + k.KompanijaID + ",'" + k.Naziv + "', '" + k.Tip + "', " + getBIt(k.PdvObveznik) + ",'" + k.Maticni + "', '" + k.Datum.ToString("yyyy-MM-dd HH:mm") + "', " + k.BrojZaposlenih + " ," + k.Korisnik.KorisnikID + ")";

                komanda.ExecuteNonQuery();




                transakcija.Commit();
                return true;
            }
            catch (Exception)
            {

                transakcija.Rollback();
                return false;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }

        }


    }
}
