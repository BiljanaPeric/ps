﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class Login : Form
    {

        Komunikacija k;
        // Korisnik kor;
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnPrijaviSe_Click(object sender, EventArgs e)
        {

            k = new Komunikacija();

            if (k.poveziSeNaServer())
            {
                Korisnik kor = new Korisnik();
                kor.KorisnickoIme = txtUser.Text;
                kor.Lozinka = txtPass.Text;
                kor = k.login(kor);

                if (kor != null)
                {
                    MessageBox.Show("USPESNO");
                    new FromaKlijent(k, kor).ShowDialog();
                }
                else { MessageBox.Show("Neuspesno"); }

            }
            else
            {
                MessageBox.Show("Neuspesno povezivanje na server");
            }
        }
    }
}
