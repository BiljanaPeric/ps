﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class UnosZaposlenog : Form
    {
        private Komunikacija k;
        private Korisnik kor;
        private Kompanija kompanija;
        private BindingList<Zaposleni> listaZaposlenih;
        Zaposleni z;
        BindingList<Banka> listaBanki;
        public UnosZaposlenog()
        {
           
        }

        public UnosZaposlenog(Komunikacija k, Korisnik kor, Kompanija kompanija, BindingList<Zaposleni> listaZaposlenih)
        {
            InitializeComponent();
            this.k = k;
            this.kor = kor;
            this.kompanija = kompanija;
            this.listaZaposlenih = listaZaposlenih;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            z = new Zaposleni();
            
            z.Ime = txtIme.Text;
            if (string.IsNullOrEmpty(z.Ime))
            {
                MessageBox.Show("Niste uneli ime");
                return;
            }
            z.Prezime = txtPrezime.Text;
            if (string.IsNullOrEmpty(z.Prezime))
            {
                MessageBox.Show("Niste uneli preime");
                return;
            }
            z.JBMG1 = txtJMBG.Text;
            if (string.IsNullOrEmpty(z.JBMG1))
            {
                MessageBox.Show("Niste uneli ");
                return;
            }

            z.ZiroRacun = txtPocetak.Text + "-" + txtZiro.Text;

            
            if (string.IsNullOrEmpty(z.ZiroRacun))
            {
                MessageBox.Show("Niste uneli");
                return;
            }
            z.Kompanija = kompanija;
            try
            {
                z.Iznos = Convert.ToDouble(txtIznos.Text);
            }
            catch (Exception)
            {

                MessageBox.Show("Niste uneli iznos");
            }
            try
            {
                z.Banka = cmbBanka.SelectedItem as Banka;
            }
            catch (Exception)
            {

                MessageBox.Show("Niste odabrali");
            }
            listaZaposlenih.Add(z);
            
        }

        private void UnosZaposlenog_Load(object sender, EventArgs e)
        {
           // listaBanki = new BindingList<Banka>();

            try
            {
                listaBanki =new BindingList<Banka>( k.vratiBanke());
                cmbBanka.DataSource = listaBanki;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void cmbBanka_SelectedIndexChanged(object sender, EventArgs e)
        {
            Banka b = cmbBanka.SelectedItem as Banka;
            txtPocetak.Text = b.JedinstveniBroj.ToString();
        }
    }
}
