﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    
    public partial class FromaKlijent : Form
    {
        public enum Tip {AkcionarkoDrustvo, DrustvoSaOgrOdgov, OrtackoDrustvo, KomandnoDrustvo ,Preduzetnik };
        Komunikacija k;
        private Korisnik kor;
        Kompanija kompanija;
        
        BindingList<Zaposleni> listaZaposlenih;

        public FromaKlijent()
        {
           
        }

        public FromaKlijent(Komunikacija k, Korisnik kor)
        {
            InitializeComponent();
            this.k = k;
            this.kor = kor;
        }

        private void FromaKlijent_Load(object sender, EventArgs e)
        {
            kompanija = new Kompanija();
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "FON Evidencija kompanija - Klijent";
            }

            cmbTip.DataSource = Enum.GetValues(typeof(Tip));
            listaZaposlenih = new BindingList<Zaposleni>();
            dataGridView1.DataSource = listaZaposlenih;
            
                }

        private void button1_Click(object sender, EventArgs e)
        {
           
            kompanija.Naziv = txtNaxiv.Text;

            new UnosZaposlenog(k, kor, kompanija,listaZaposlenih).ShowDialog();
            dataGridView1.Refresh();
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            try
            {
                Zaposleni z = dataGridView1.CurrentRow.DataBoundItem as Zaposleni;
                listaZaposlenih.Remove(z);
            }
            catch (Exception)
            {

                MessageBox.Show("Niste odabrali zaposlenog");
                return;
            }
           

        }

        private void btnEvidentiraj_Click(object sender, EventArgs e)
        {
            kompanija = new Kompanija();
            kompanija.Naziv = txtNaxiv.Text;
            try
            {
                kompanija.Tip = cmbTip.SelectedItem.ToString();
            }
            catch (Exception)
            {

                throw;
            }
            if (checkBox1.Checked)
            {
                kompanija.PdvObveznik = true;
            }
            else
            {
                kompanija.PdvObveznik = false; 
            }
            kompanija.Maticni = txtMaticni.Text;
            try
            {
                kompanija.Datum = DateTime.ParseExact(txtDatum.Text, "dd.MM.yyyy", null);
                if (kompanija.Datum == null)
                {
                    MessageBox.Show("Niste uneli datum!");
                    return;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Nije validan datum!");
                return;
            }
            kompanija.Korisnik = kor;
            kompanija.BrojZaposlenih = listaZaposlenih.Count();




          if(k.sacuvaj(kompanija))
            {
                MessageBox.Show("Sacuvano");
            }
            else
            {
                MessageBox.Show("Greska");
            }
        }
    }
}
