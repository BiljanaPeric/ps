Select g.Naziv,g.DatumRegistracije,g.UkupnoSubvencija,sum(s.BrojGrla) as 'Ukupno grla' 
from Gazdinstvo g inner join Stado s on (g.GazdinstvoID = s.GazdinstvoID) inner join Zivotinja z on (s.ZivotinjaID=z.ZivotinjaID)
group by g.Naziv,g.DatumRegistracije,g.UkupnoSubvencija