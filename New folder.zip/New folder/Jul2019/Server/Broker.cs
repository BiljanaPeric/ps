﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ProSoft-Jul2019;Integrated Security=True");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        //metode

        public Poljoprivrednik LogIn(Poljoprivrednik p)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Poljoprivrednik where KorisnickoIme = '"+p.KorisnickoIme+"' and Lozinka = '"+p.Lozinka+"'";
                SqlDataReader citac = komanda.ExecuteReader();
                if (citac.Read())
                {
                    p.Id = citac.GetInt32(0);
                    p.Ime = citac.GetString(1);
                    p.Prezime = citac.GetString(2);

                    citac.Close();
                    return p;
                }
                citac.Close();
                return null;
            }
            catch (Exception)
            {

                return null;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public int vratiSifruGazd()
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select max(GazdinstvoID) from Gazdinstvo";
                try
                {
                    int sifra = Convert.ToInt32(komanda.ExecuteScalar());
                    return sifra + 1;
                }
                catch (Exception)
                {

                    return 1;
                }
            }
            catch (Exception)
            {

                throw;
            }finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public bool KreirajGazdinstvo(Gazdinstvo g)
        {
            try
            {
                konekcija.Open();
                komanda.CommandText = "Insert into Gazdinstvo values (" + g.Id + ",'" + g.Naziv + "','" + g.DatumRegistracije.ToString("yyyy-MM-dd") + "'," + g.UkupnoSubvencija + "," + g.Poljoprivrednik.Id + ")";
                komanda.ExecuteNonQuery();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<Zivotinja> vratiSveZivotinje()
        {
            List<Zivotinja> lista = new List<Zivotinja>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Zivotinja";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Zivotinja z = new Zivotinja();
                    z.Id = citac.GetInt32(0);
                    z.Naziv = citac.GetString(1);
                    z.AutohtonaVrsta = citac.GetBoolean(2);
                    z.SubvencijaPoGrlu = citac.GetDouble(3);

                    lista.Add(z);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public bool sacuvajGazdinstvo(Gazdinstvo g)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);

                komanda.CommandText = "Update Gazdinstvo set UkupnoSubvencija = " + g.UkupnoSubvencija + " where GazdinstvoID = "+g.Id+"";
                komanda.ExecuteNonQuery();

                foreach (Stado stado in g.ListaStada)
                {
                    komanda.CommandText = "Insert into Stado values(" + g.Id + "," + stado.Id + "," + stado.BrojGrla + "," + stado.IznosSubvencije + "," + stado.Zivotinja.Id + ")";
                    komanda.ExecuteNonQuery();
                }

                transakcija.Commit();
                return true;
            }
            catch (Exception)
            {
                transakcija.Rollback();
                return false;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public List<KlasaZaServer> vratiZaServer(string kriterijum)
        {
            List<KlasaZaServer> lista = new List<KlasaZaServer>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select g.Naziv,g.DatumRegistracije,g.UkupnoSubvencija,sum(s.BrojGrla) as 'Ukupno grla' from Gazdinstvo g inner join Stado s on (g.GazdinstvoID = s.GazdinstvoID) inner join Zivotinja z on (s.ZivotinjaID=z.ZivotinjaID) "+kriterijum+ " group by g.Naziv,g.DatumRegistracije,g.UkupnoSubvencija";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    KlasaZaServer k = new KlasaZaServer();

                    k.Gazdinstvo = citac.GetString(0);
                    k.DatumRegistracije = citac.GetDateTime(1);
                    k.UkupnoSubvencije = citac.GetDouble(2);

                    try
                    {
                        k.UkupnoGrla = Convert.ToInt32(citac.GetValue(3));
                    }
                    catch (Exception)
                    {

                        
                    }
                    lista.Add(k);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                return null;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }
    }
}
