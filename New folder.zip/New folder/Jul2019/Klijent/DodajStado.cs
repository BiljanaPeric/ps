﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class DodajStado : Form
    {
        private Komunikacija k;
        private Poljoprivrednik p;
        private Gazdinstvo g;
        private BindingList<Stado> listaStada;

        public DodajStado()
        {
            
        }

        public DodajStado(Komunikacija k, Poljoprivrednik p, Gazdinstvo g, BindingList<Stado> listaStada)
        {
            InitializeComponent();
            this.k = k;
            this.p = p;
            this.g = g;
            this.listaStada = listaStada;
        }

        private void DodajStado_Load(object sender, EventArgs e)
        {
            cmbZivotinja.DataSource = k.vratiSveZivotinje();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Stado s = new Stado();

            s.Gazdinstvo = g;
            s.Id = listaStada.Count() + 1;

            try
            {
                s.Zivotinja = cmbZivotinja.SelectedItem as Zivotinja;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali zivotinju!");
                return;
            }
            try
            {
                if (Convert.ToInt32(txtBrojGrla.Text) > 0)
                {
                    s.BrojGrla = Convert.ToInt32(txtBrojGrla.Text);
                }
                else
                {
                    MessageBox.Show("Broj grla mora biti veci od 0!");
                    return;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Niste uneli dobar broj grla!");
                return;
            }
           
            try
            {
                s.IznosSubvencije =Convert.ToDouble(txtIznosSub.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Nije dobar iznos subvencije!");
                return;
            }
            //Zivotinja z = cmbZivotinja.SelectedItem as Zivotinja;
            foreach (Stado stado in g.ListaStada)
            {
                if (stado.Zivotinja.Naziv == s.Zivotinja.Naziv)
                {
                    MessageBox.Show("Zivotinja se vec nalazi u nekom stadu!");
                    return;
                }
            }

            listaStada.Add(s);

            this.Close();
        }

        private void cmbZivotinja_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }

        private void txtBrojGrla_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Zivotinja z = cmbZivotinja.SelectedItem as Zivotinja;
                txtIznosSub.Text = Convert.ToDouble(z.SubvencijaPoGrlu * Convert.ToDouble(txtBrojGrla.Text)).ToString();
            }
            catch (Exception)
            {
                MessageBox.Show("Greska prilikom racunanja subnencije!");
                return;
            }
        }
    }
}
