﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class LogIn : Form
    {
        Komunikacija k;
        public LogIn()
        {
            InitializeComponent();
        }

        private void LogIn_Load(object sender, EventArgs e)
        {
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "Povezan!";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Poljoprivrednik p = new Poljoprivrednik();

            try
            {
                p.KorisnickoIme = textBox1.Text;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste uneli korisnicko ime!");
                return;
            }
            try
            {
                p.Lozinka = textBox2.Text;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste uneli lozinku!");
                return;
            }
            p = k.LogIn(p);
            if (p != null)
            {
                new FormaKlijent(k, p).ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Neuspelo logovanje!");
            }
        }
    }
}
