﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class FormaKlijent : Form
    {
        private Komunikacija k;
        private Poljoprivrednik p;
        Gazdinstvo g;
        

        //Komunikacija k;
        public FormaKlijent()
        {
            
        }

        public FormaKlijent(Komunikacija k, Poljoprivrednik p)
        {
            InitializeComponent();
            this.k = k;
            this.p = p;
        }

        private void FormaKlijent_Load(object sender, EventArgs e)
        {
            //k = new Komunikacija();
            //if (k.poveziSeNaServer())
            //{
            //    this.Text = "Povezan!";
            //}
            this.Text = "[FON] Unos gazdinstva - Klijent";
            lblID.Text = k.vratiSifru().ToString();

            g = new Gazdinstvo();
            dataGridView1.DataSource = g.ListaStada;


        }

        private void btnKreiraj_Click(object sender, EventArgs e)
        {
            

            try
            {
                g.Id = Convert.ToInt32(lblID.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Nije dobar ID!");
                return;
            }

            g.Naziv = txtNaziv.Text;
            if (g.Naziv == "")
            {
                MessageBox.Show("Niste uneli naziv!");
                return;
            }
            try
            {
                g.DatumRegistracije = DateTime.ParseExact(txtDatumReg.Text, "dd.MM.yyyy", null);
            }
            catch (Exception)
            {
                MessageBox.Show("Datum nije dobar!");
                return;
            }
            if (g.ListaStada.Count() < 1)
            {
                MessageBox.Show("Gazdinstvo mora imati bar jedno stado!");
                return;
            }
            try
            {
                g.UkupnoSubvencija = Convert.ToDouble(txtUkupnoSub.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Nije dobar iznos subvencija ili niste dodali nijedno stado!");
                return;
            }

            g.Poljoprivrednik = p;
            //if (g.ListaStada.Count() < 1)
            //{
            //    MessageBox.Show("Gazdinstvo mora imati bar jedno stado!");
            //    return;
            //}
            if (k.KreirajGazd(g))
            {
                MessageBox.Show("Uspesno kreirano gazdinstvo!");
            }
            else
            {
                MessageBox.Show("Neuspesno kreiranje!");
            }
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            new DodajStado(k, p, g, g.ListaStada).ShowDialog();

            double sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(dataGridView1.Rows[i].Cells[4].Value);
            }
            txtUkupnoSub.Text = sum.ToString();
        }

        private void txtUkupnoSub_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {
            try
            {
                g.UkupnoSubvencija = Convert.ToDouble(txtUkupnoSub.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Nije dobto ukupno subvencija!");
                return;
            }

            //g.Poljoprivrednik = p;
            if (g.ListaStada.Count() < 1)
            {
                MessageBox.Show("Gazdinstvo mora imati bar jedno stado!");
                return;
            }

            if (k.SacuvajGazdinstvo(g))
            {
                MessageBox.Show("Uspesno azurirano gazdinstvo i sacuvana stada!");
            }
            else
            {
                MessageBox.Show("Neuspesno!");
            }
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            try
            {
                Stado s = dataGridView1.CurrentRow.DataBoundItem as Stado;
                g.ListaStada.Remove(s);
                txtUkupnoSub.Text = (Convert.ToDouble(txtUkupnoSub.Text) - s.IznosSubvencije).ToString();
            }
            catch (Exception)
            {
                MessageBox.Show("niste odabrali stado za brisanje");
                
            }
        }
    }
}
