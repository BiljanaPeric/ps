﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Zivotinja
    {
        int id;
        string naziv;
        bool autohtonaVrsta;
        double subvencijaPoGrlu;
        //BindingList<Stado> lista;

        //public Zivotinja()
        //{
        //    Lista = new BindingList<Stado>();
        //}
        public override string ToString()
        {
            return naziv;
        }

        [Browsable(false)]
        public int Id { get => id; set => id = value; }
        [DisplayName("Zivotinja")]
        public string Naziv { get => naziv; set => naziv = value; }

        [DisplayName("Autohtona")]
        public bool AutohtonaVrsta { get => autohtonaVrsta; set => autohtonaVrsta = value; }
        public double SubvencijaPoGrlu { get => subvencijaPoGrlu; set => subvencijaPoGrlu = value; }
        //public BindingList<Stado> Lista { get => lista; set => lista = value; }
    }
}
