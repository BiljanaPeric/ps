﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public class KlasaZaServer
    {
        string gazdinstvo;
        DateTime datumRegistracije;
        double ukupnoSubvencije;
        int ukupnoGrla;
        string stado;

        public string Gazdinstvo { get => gazdinstvo; set => gazdinstvo = value; }
        public DateTime DatumRegistracije { get => datumRegistracije; set => datumRegistracije = value; }
        public double UkupnoSubvencije { get => ukupnoSubvencije; set => ukupnoSubvencije = value; }
        public int UkupnoGrla { get => ukupnoGrla; set => ukupnoGrla = value; }
        [Browsable(false)]
        public string Stado { get => stado; set => stado = value; }

        public string stado1
        {
            get
            {
                Zivotinja z = new Zivotinja();
                Stado s = new Stado();
                return z.Naziv + ":" + s.BrojGrla+",";
            }
        }
    }
}
