﻿namespace Server
{
    partial class FormServer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbDatOD = new System.Windows.Forms.CheckBox();
            this.cbDatDO = new System.Windows.Forms.CheckBox();
            this.cbLab = new System.Windows.Forms.CheckBox();
            this.txtDatumOD = new System.Windows.Forms.TextBox();
            this.txtDatumDO = new System.Windows.Forms.TextBox();
            this.cmbLab = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // cbDatOD
            // 
            this.cbDatOD.AutoSize = true;
            this.cbDatOD.Location = new System.Drawing.Point(12, 12);
            this.cbDatOD.Name = "cbDatOD";
            this.cbDatOD.Size = new System.Drawing.Size(75, 17);
            this.cbDatOD.TabIndex = 0;
            this.cbDatOD.Text = "Datum od:";
            this.cbDatOD.UseVisualStyleBackColor = true;
            // 
            // cbDatDO
            // 
            this.cbDatDO.AutoSize = true;
            this.cbDatDO.Location = new System.Drawing.Point(12, 35);
            this.cbDatDO.Name = "cbDatDO";
            this.cbDatDO.Size = new System.Drawing.Size(75, 17);
            this.cbDatDO.TabIndex = 1;
            this.cbDatDO.Text = "Datum do:";
            this.cbDatDO.UseVisualStyleBackColor = true;
            // 
            // cbLab
            // 
            this.cbLab.AutoSize = true;
            this.cbLab.Location = new System.Drawing.Point(12, 58);
            this.cbLab.Name = "cbLab";
            this.cbLab.Size = new System.Drawing.Size(84, 17);
            this.cbLab.TabIndex = 2;
            this.cbLab.Text = "Laboratorija:";
            this.cbLab.UseVisualStyleBackColor = true;
            // 
            // txtDatumOD
            // 
            this.txtDatumOD.Location = new System.Drawing.Point(120, 10);
            this.txtDatumOD.Name = "txtDatumOD";
            this.txtDatumOD.Size = new System.Drawing.Size(313, 20);
            this.txtDatumOD.TabIndex = 3;
            // 
            // txtDatumDO
            // 
            this.txtDatumDO.Location = new System.Drawing.Point(120, 33);
            this.txtDatumDO.Name = "txtDatumDO";
            this.txtDatumDO.Size = new System.Drawing.Size(313, 20);
            this.txtDatumDO.TabIndex = 4;
            // 
            // cmbLab
            // 
            this.cmbLab.FormattingEnabled = true;
            this.cmbLab.Location = new System.Drawing.Point(120, 56);
            this.cmbLab.Name = "cmbLab";
            this.cmbLab.Size = new System.Drawing.Size(313, 21);
            this.cmbLab.TabIndex = 5;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 93);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(421, 150);
            this.dataGridView1.TabIndex = 6;
            // 
            // FormServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 258);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.cmbLab);
            this.Controls.Add(this.txtDatumDO);
            this.Controls.Add(this.txtDatumOD);
            this.Controls.Add(this.cbLab);
            this.Controls.Add(this.cbDatDO);
            this.Controls.Add(this.cbDatOD);
            this.Name = "FormServer";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FormServer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox cbDatOD;
        private System.Windows.Forms.CheckBox cbDatDO;
        private System.Windows.Forms.CheckBox cbLab;
        private System.Windows.Forms.TextBox txtDatumOD;
        private System.Windows.Forms.TextBox txtDatumDO;
        private System.Windows.Forms.ComboBox cmbLab;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

