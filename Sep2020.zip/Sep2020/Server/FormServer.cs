﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class FormServer : Form
    {
        Server s;
        Timer t;
        public FormServer()
        {
            InitializeComponent();
        }

    

        private void FormServer_Load(object sender, EventArgs e)
        {
            s = new Server();
            if (s.pokreniServer())
            {
                this.Text = " Server je pokrenut!";

                cmbLab.DataSource = Broker.DajSesiju().VratiSveLaboratorije();

                t = new Timer();
                t.Interval = 5000;
                t.Tick += vrati;
                t.Start();
            }
        }

        private void vrati(object sender, EventArgs e)
        {
            string kriterijum = "";

            if (cbDatOD.Checked)
            {
                try
                {
                    DateTime datum = DateTime.ParseExact(txtDatumOD.Text,"dd.MM.yyyy",null);
                    kriterijum += " and CAST(DatumVremeRezultata as date)>=CAST('" + datum.ToString("yyyy-MM-dd") + "' as date) ";
                }
                catch (Exception)
                {

                   
                }

              
            }

            if (cbDatDO.Checked)
            {
               
                try
                {
                    DateTime datum = DateTime.ParseExact(txtDatumDO.Text, "dd.MM.yyyy", null);
                    kriterijum += " and CAST(DatumVremeRezultata as date)<=CAST('" + datum.ToString("yyyy-MM-dd") + "' as date) ";
                }
                catch (Exception)
                {


                }              

            }

            if (cbLab.Checked)
            {
                
                Laboratorija l = cmbLab.SelectedItem as Laboratorija;
                if (l != null)
                {
                    kriterijum += " and LaboratorijaID=" + l.Id + " ";
                }

            }


            dataGridView1.DataSource = Broker.DajSesiju().VratiZaServer(kriterijum);
        }
    }
}
