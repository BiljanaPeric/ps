﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;

namespace Server
{
    class NitKlijenta
    {
        private NetworkStream tok;
        BinaryFormatter formater;

        public NitKlijenta(NetworkStream tok)
        {
            this.tok = tok;
            formater = new BinaryFormatter();

            ThreadStart ts = obradiKlijenta;
            Thread nit = new Thread(ts);
            nit.Start();
        }

        void obradiKlijenta()
        {
            try
            {
                int operacija = 0;

                while (operacija != (int)Operacije.Kraj)
                {
                    TransferKlasa transfer = formater.Deserialize(tok) as TransferKlasa;
                    switch (transfer.Operacija)
                    {

                        case Operacije.Login:
                            transfer.Rezultat = Broker.DajSesiju().Login(transfer.TransferObjekat as Laborant);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.VratiZahteve:
                            transfer.Rezultat = Broker.DajSesiju().vratiNeobradjeneZahteve(transfer.TransferObjekat as Laboratorija);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.SacuvajIzmene:
                            transfer.Rezultat = Broker.DajSesiju().SacuvajIzmene(transfer.TransferObjekat as List<Zahtev>);
                            formater.Serialize(tok, transfer);
                            break;

                        case Operacije.Kraj:operacija = 1;
                            Server.listaTokova.Remove(tok);
                            break;
                        default:
                            break;
                    }
                }
            }
            catch (Exception)
            {
                Server.listaTokova.Remove(tok);
            }
        }
    }
}
