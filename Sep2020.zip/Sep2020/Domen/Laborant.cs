﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Laborant
    {
        public override string ToString()
        {
            return ime+" "+prezime;
        }

        int id;
        string ime;
        string prezime;
        string korisnickoIme;
        string lozinka;
        Laboratorija laboratorija;

        public int Id { get => id; set => id = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public string KorisnickoIme { get => korisnickoIme; set => korisnickoIme = value; }
        public string Lozinka { get => lozinka; set => lozinka = value; }
        public Laboratorija Laboratorija { get => laboratorija; set => laboratorija = value; }
    }
}
