﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public class ServerObjekat
    {
        string tip;
        int brPozitivnih;
        int brNegativnih;

        public string Tip { get => tip; set => tip = value; }
        public int BrPozitivnih { get => brPozitivnih; set => brPozitivnih = value; }
        public int BrNegativnih { get => brNegativnih; set => brNegativnih = value; }
    }
}
