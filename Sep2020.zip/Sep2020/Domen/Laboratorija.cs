﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Laboratorija
    {
        public override string ToString()
        {
            return naziv;
        }

        public override bool Equals(object obj)
        {
            var laboratorija = obj as Laboratorija;
            return laboratorija != null &&
                   id == laboratorija.id;
        }

        int id;
        string naziv;
        int kapacitet;
        string grad;

        public int Id { get => id; set => id = value; }
        public string Naziv { get => naziv; set => naziv = value; }
        public int Kapacitet { get => kapacitet; set => kapacitet = value; }
        public string Grad { get => grad; set => grad = value; }
    }
}
