﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Zahtev
    {
        int id;
        DateTime datumTestiranja;
        bool hitno;
        string tip;
        string rezultat;
        DateTime datumRezultata;
        string napomena;
        string status;
        Laboratorija laboratorija;
        Laborant laborant;
        OsiguranoLice osiguranoLice;

        [Browsable(false)]
        public int Id { get => id; set => id = value; }
        public DateTime DatumTestiranja { get => datumTestiranja; set => datumTestiranja = value; }
        public bool Hitno { get => hitno; set => hitno = value; }
        public string Tip { get => tip; set => tip = value; }
        public string Rezultat { get => rezultat; set => rezultat = value; }
        public DateTime DatumRezultata { get => datumRezultata; set => datumRezultata = value; }
        public string Napomena { get => napomena; set => napomena = value; }
        public string Status { get => status; set => status = value; }
        public Laboratorija Laboratorija { get => laboratorija; set => laboratorija = value; }
        public Laborant Laborant { get => laborant; set => laborant = value; }
        public OsiguranoLice OsiguranoLice { get => osiguranoLice; set => osiguranoLice = value; }
    }
}
