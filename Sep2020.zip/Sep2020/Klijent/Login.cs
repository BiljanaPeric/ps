﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class Login : Form
    {
        Komunikacija k;
        public Login()
        {
            InitializeComponent();
        }

        private void FormKlijent_Load(object sender, EventArgs e)
        {
           
        }

        private void FormKlijent_FormClosed(object sender, FormClosedEventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            k = new Komunikacija();
            if (k.povesiSeNaServer())
            {
                Laborant l = new Laborant() { KorisnickoIme = txtKorIme.Text, Lozinka = txtLozinka.Text };
                l = k.Login(l);

                if (l != null)
                {
                    new GlavnaForma(k, l).ShowDialog();
                }
                else
                {
                    MessageBox.Show("Laborant ne postoji!");
                }
            }
            else
            {
                MessageBox.Show("Neuspelo povezivanje na server!");
            }
        }
    }
}
