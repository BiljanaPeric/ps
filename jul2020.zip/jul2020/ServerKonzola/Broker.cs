﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domen;
using System.Data;
using System.Data.SqlClient;
namespace ServerKonzola
{
    public class Broker
    {

        SqlConnection konekcija;
        SqlTransaction transakcija;
        SqlCommand komanda;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=jul12020;Integrated Security=True");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        static Broker instanca;

        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        public Meteorolog login(Meteorolog m)
        {


            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Meteorolog where KorisnickoIme ='" + m.KorisnickoIme + "' and Lozinka ='" + m.Lozinka + "'";
                SqlDataReader citac = komanda.ExecuteReader();

                if (citac.Read())
                {
                    m.MeteorologID = citac.GetInt32(0);
                    m.Ime = citac.GetString(1);
                    m.Prezime = citac.GetString(2);

                    // return m;
                }
                citac.Close();

                return m;
            }



            catch (Exception)
            {

                return null;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }


        public List<Region> vratiRegione()
        {
            List<Region> lista = new List<Region>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Region";
                SqlDataReader citac = komanda.ExecuteReader();

                while (citac.Read())
                {
                    Region r = new Region();
                    r.RegionID = citac.GetInt32(0);
                    r.Naziv = citac.GetString(1);
                    r.Opis = citac.GetString(2);
                    lista.Add(r);

                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                return null;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public int vratiIdPrognoze()
        {

            try
            {
                komanda.CommandText = "Select max(PrognozaId) from Prognoza";
                try
                {
                    int sifra = Convert.ToInt32(komanda.ExecuteScalar());
                    return sifra + 1;
                }
                catch (Exception)
                {

                    return 1;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        public int getBit(bool b)
        {
            if (b) return 1;
            return 0;

        }
        public int vratiRBPrognoze()
        {
            try
            {
                komanda.CommandText = "Select max(RB) from PrognozaRegion";
                try
                {
                    int rb = Convert.ToInt32(komanda.ExecuteScalar());
                    return rb + 1;
                }
                catch (Exception)
                {

                    return 0;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }
        public bool sacuvajSve(Prognoza p)
        {

            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);
                p.PrognozaID = vratiIdPrognoze();

                //List<Region> lista = vratiRegione();

                //foreach (Region r in lista)
                //{
                //    if (!pronadjiUListi(p).Contains(r)){
                //        System.Windows.Forms.MessageBox.Show("NIse uneli za sve regione");
                //        return false;

                //    }
                //}

                komanda.CommandText = "Insert into Prognoza values(" + p.PrognozaID + ", '" + p.Dan.ToString("yyyy-MM-dd HH:mm") + "','" + p.Opis + "', " + p.Meteorolog.MeteorologID + ")";
                komanda.ExecuteNonQuery();

                foreach (PrognozaRegion pr in p.ListaPrognozaRegion)
                {
                    komanda.CommandText = "Insert into PrognozaRegion values( " + p.PrognozaID + "," + pr.Rb + "," + Convert.ToDouble(pr.Temperatura) + ",'" + pr.MeteoAlarm + "','" + pr.Pojava + "'," + pr.Region.RegionID + ")";
                    komanda.ExecuteNonQuery();
                }

                transakcija.Commit();
                return true;

            }
            catch (Exception)
            {

                transakcija.Rollback();
                return false;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }


        public List<Region> pronadjiUListi(Prognoza p)
        {
            List<Region> lista = new List<Region>();

            foreach(PrognozaRegion pr in p.ListaPrognozaRegion)
            {
                lista.Add(pr.Region);
            }
            return lista;
        }
    }
}
