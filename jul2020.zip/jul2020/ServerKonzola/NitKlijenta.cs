﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domen;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;


namespace ServerKonzola
{
    public class NitKlijenta
        
    {
        private NetworkStream tok;
        BinaryFormatter formater;
        public NitKlijenta(NetworkStream tok)
        {
            this.tok = tok;
            formater = new BinaryFormatter();

            ThreadStart ts = obradi;
            new Thread(ts).Start();
        }

        void obradi()
        {
            try
            {
                int operacija = 0;
                while (operacija != (int)Operacije.kraj)
                {
                    TransferKlasa transfer = formater.Deserialize(tok) as TransferKlasa;

                    switch (transfer.Operacija)
                    {
                        case Operacije.Login:
                            transfer.Rezultat = Broker.dajSesiju().login(transfer.TransferObjekat as Meteorolog);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.VratiRegion:
                            transfer.Rezultat = Broker.dajSesiju().vratiRegione();
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.Sacuva:
                            transfer.Rezultat = Broker.dajSesiju().sacuvajSve(transfer.TransferObjekat as Prognoza);
                            formater.Serialize(tok, transfer);
                            break;
                        case Operacije.kraj:operacija = 1;
                            break;
                        default:
                            break;

                    }
                }
            }
            catch (Exception)
            {

               
            }
        }
    }
}
