﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Domen
{
    [Serializable]
    public class PrognozaRegion
    {

        int rb;
        double temperatura;
        string meteoAlarm;
        string pojava;
        Region region;
        [Browsable(false)]
        public int Rb { get => rb; set => rb = value; }
        public double Temperatura { get => temperatura; set => temperatura = value; }
        public Region Region { get => region; set => region = value; }
        public string MeteoAlarm { get => meteoAlarm; set => meteoAlarm = value; }
        public string Pojava { get => pojava; set => pojava = value; }
        
    }
}
