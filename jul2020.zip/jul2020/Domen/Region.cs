﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domen
{
    [Serializable]
    public class Region
    {
        public override string ToString()
        {
            return Naziv;
        }
        int regionID;
        string naziv;
        string opis;

        public int RegionID { get => regionID; set => regionID = value; }
        public string Naziv { get => naziv; set => naziv = value; }
        public string Opis { get => opis; set => opis = value; }
    }
}
