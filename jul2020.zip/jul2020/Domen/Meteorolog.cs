﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domen
{
    [Serializable]
    public class Meteorolog
    {
        int meteorologID;
        string ime;
        string prezime;
        string korisnickoIme;
        string lozinka;

        public int MeteorologID { get => meteorologID; set => meteorologID = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public string KorisnickoIme { get => korisnickoIme; set => korisnickoIme = value; }
        public string Lozinka { get => lozinka; set => lozinka = value; }
    }
}
