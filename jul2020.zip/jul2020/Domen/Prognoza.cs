﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Domen
{
    [Serializable]
     public class Prognoza
    {
        int prognozaID;
        string opis;
        Meteorolog meteorolog;
        DateTime dan;
        BindingList<PrognozaRegion> listaPrognozaRegion;
        public Prognoza()
        {
            listaPrognozaRegion = new BindingList<PrognozaRegion>();
        }
        public int PrognozaID { get => prognozaID; set => prognozaID = value; }
        public string Opis { get => opis; set => opis = value; }
        public Meteorolog Meteorolog { get => meteorolog; set => meteorolog = value; }
        public DateTime Dan { get => dan; set => dan = value; }
        public BindingList<PrognozaRegion> ListaPrognozaRegion { get => listaPrognozaRegion; set => listaPrognozaRegion = value; }
    }
}
