﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class FromaKlijent : Form
    {
        public enum MeteoAlarm { Zeleni, Zuti, Narandzasti, Crveni };
        Komunikacija k;
        private Meteorolog m;
        BindingList<Domen.Region> listaRegiona;
        // BindingList<PrognozaRegion> listPrognozaRegion;
        Prognoza p;
        public FromaKlijent()
        {

        }

        public FromaKlijent(Meteorolog m, Komunikacija k)
        {
            InitializeComponent();
            this.m = m;
            this.k = k;
        }

        private void FromaKlijent_Load(object sender, EventArgs e)
        {
            try
            {
                listaRegiona = new BindingList<Domen.Region>(k.vratiRegione());
                cmbregion.DataSource = listaRegiona;
            }
            catch (Exception)
            {

                throw;
            }
            p = new Prognoza();
            this.Text = "Vremenska prognoza - Klijentski program";
            cmbAlarm.DataSource = Enum.GetValues(typeof(MeteoAlarm));
            dataGridView1.DataSource = p.ListaPrognozaRegion;

        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void brnObrisi_Click(object sender, EventArgs e)
        {
            try
            {
                PrognozaRegion pr = dataGridView1.CurrentRow.DataBoundItem as PrognozaRegion;
                p.ListaPrognozaRegion.Remove(pr);
            }
            catch (Exception)
            {

                MessageBox.Show("Niste odabrali");
            }
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {

            PrognozaRegion progR = new PrognozaRegion();
            progR.Rb = p.ListaPrognozaRegion.Count() + 1;
            try
            {
                progR.Temperatura = Convert.ToDouble(txtTemp.Text);

                if (progR.Temperatura < -50 || progR.Temperatura > 50)
                {
                    MessageBox.Show("NIste uneli odgovaracuju temperaturu");
                    return;
                }

            }
            catch (Exception)
            {

                MessageBox.Show("Niste uneli");
                txtTemp.Focus();
                return;
            }
            try
            {
                progR.MeteoAlarm = cmbAlarm.SelectedItem.ToString();
            }
            catch (Exception)
            {

                MessageBox.Show("Niste odabrali");
            }
            try
            {
                progR.Pojava = cmbPOjava.SelectedItem.ToString();
            }
            catch (Exception)
            {

                MessageBox.Show("Niste odabrali");
            }
            try
            {
                progR.Region = cmbregion.SelectedItem as Domen.Region;
            }
            catch (Exception)
            {

                MessageBox.Show("Niste odabrali");
            }

            p.ListaPrognozaRegion.Add(progR);
        }

        private void brnSacuvaj_Click(object sender, EventArgs e)
        {
            p.Meteorolog = m;
            try
            {
                p.Dan = DateTime.ParseExact(txtDan.Text, "dd.MM.yyyy", null);

                if (p.Dan == null)
                {
                    MessageBox.Show("Niste uneli datum");
                    return;
                }
            }
            catch (Exception)
            {

                MessageBox.Show("NIje validan datum");
                return;
            }

            p.Opis = txtOpis.Text;
            if (string.IsNullOrEmpty(p.Opis))
            {
                MessageBox.Show("NIste uneli");
                return;
            }

           

            if (k.sacuvaj(p))
            {
                MessageBox.Show("Sacuvano");
            }
            else
            {
                MessageBox.Show("Neuspesno");
            }
        }
    }
}
