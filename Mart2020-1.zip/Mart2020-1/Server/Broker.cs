﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Data;
using System.Data.SqlClient;

namespace Server
{
    public class Broker
    {
        SqlCommand komanda;
        SqlConnection konekcija;
        SqlTransaction transakcija;

        void konektujSe()
        {
            konekcija = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=mart2020;Integrated Security=True");
            komanda = konekcija.CreateCommand();
        }

        Broker()
        {
            konektujSe();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null) instanca = new Broker();
            return instanca;
        }

        //metode

        public List<Publikacija> VratiSvePublikacije()
        {
            List<Publikacija> lista = new List<Publikacija>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select * from Publikacija";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Publikacija p = new Publikacija();
                    p.Id = citac.GetInt32(0);
                    p.Naziv = citac.GetString(1);

                    lista.Add(p);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }

        public int VratiIdIzdanja()
        {
            try
            {
                komanda.CommandText = "Select max(IzdanjeID) from Izdanje";
                try
                {
                    int sifra = Convert.ToInt32(komanda.ExecuteScalar());
                    return sifra + 1;
                }
                catch (Exception)
                {
                    return 1;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        public int VratiRBVesti()
        {
            try
            {
                komanda.CommandText = "Select max(RB) from Vest";
                try
                {
                    int sifra = Convert.ToInt32(komanda.ExecuteScalar());
                    return sifra + 1;
                }
                catch (Exception)
                {
                    return 1;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public bool SacuvajIzdanje(Izdanje i)
        {
            try
            {
                konekcija.Open();
                transakcija = konekcija.BeginTransaction();
                komanda = new SqlCommand("", konekcija, transakcija);

                if (ProveriIzdanje(i.Datum,i.Broj))
                {
                    transakcija.Rollback();
                    System.Windows.Forms.MessageBox.Show("Vec postoji izdanje sa tim brojem ili datuomom!");
                    return false;
                }

                i.Id = VratiIdIzdanja();
                komanda.CommandText = "Insert into Izdanje values (" + i.Id + ",'" + i.Datum + "'," + i.Broj + "," + i.Publikacija.Id + ")";
                komanda.ExecuteNonQuery();

                foreach (Vest v in i.ListaVesti)
                {
                    v.Rb = VratiRBVesti();
                    komanda.CommandText = "Insert into Vest values (" + i.Id + "," + v.Rb + ",'" + v.Naslov + "','" + v.Tekst + "') ";
                    komanda.ExecuteNonQuery();
                }

                transakcija.Commit();
                return true;

            }
            catch (Exception)
            {
                transakcija.Rollback();
                return false;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }
        public List<Izdanje> VratiSvaIzdanja()
        {
            List<Izdanje> lista = new List<Izdanje>();
            try
            {
                //konekcija.Open();
                komanda.CommandText = "Select * from Izdanje";
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Izdanje i = new Izdanje();
                    i.Id = citac.GetInt32(0);
                    i.Datum = citac.GetDateTime(1);
                    i.Broj = citac.GetInt32(2);
                    

                    lista.Add(i);
                }
                citac.Close();
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
        }


        public bool ProveriIzdanje(DateTime datum, int broj)
        {
            try
            {
                foreach (Izdanje izdanje in VratiSvaIzdanja())
                {
                    if (izdanje.Datum == datum || izdanje.Broj == broj)
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Vest> vratiZaServer(string kriterijum)
        {
            List<Vest> list = new List<Vest>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Select p.Naziv,v.RB,v.Naslov,v.Tekst from Vest v inner join Izdanje i on v.IzdanjeID = i.IzdanjeID inner join Publikacija p on i.PublikacijaID=p.PublikacijaID "+kriterijum;
                SqlDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Vest v = new Vest();
                    v.Publikacija = new Publikacija();
                    v.Publikacija.Naziv = citac.GetString(0);
                    v.Rb = citac.GetInt32(1);
                    v.Naslov = citac.GetString(2);
                    v.Tekst = citac.GetString(3);

                    list.Add(v);
                }
                citac.Close();
                return list;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (konekcija != null) konekcija.Close();
            }
        }
    }
}
