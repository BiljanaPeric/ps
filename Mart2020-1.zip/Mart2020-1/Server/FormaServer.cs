﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server
{
    public partial class FormaServer : Form
    {
        Server s;
        Timer t;

        bool buttonClicked;
        public FormaServer()
        {
            InitializeComponent();
        }

        private void FormaServer_Load(object sender, EventArgs e)
        {
            s = new Server();
            if (s.pokreniServer())
            {
                this.Text = "Pretraga vesti - Serverski program";
            }

            t = new Timer();
            t.Interval = 5000;
            t.Tick += osvezi;
            t.Start();
        }

        private void osvezi(object sender, EventArgs e)
        {
            string uslov = "";
            dataGridView1.DataSource = Broker.dajSesiju().vratiZaServer(uslov);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string uslov = "";
            Izdanje izd = new Izdanje();
            try
            {
                if (txtDatum.Text == "")
                {
                    osvezi(sender, e);
                    return;
                }
                else
                {
                    izd.Datum = DateTime.ParseExact(txtDatum.Text, "dd.MM.yyyy", null);
                    
                }
            }
            catch (Exception)
            {
                //MessageBox.Show("Nije validan datum!");
            }
            
            uslov = "where i.Datum = '" + izd.Datum + "'";
            dataGridView1.DataSource = Broker.dajSesiju().vratiZaServer(uslov);
            t.Tick += button1_Click;
            //buttonClicked = true;
        }
    }
}
