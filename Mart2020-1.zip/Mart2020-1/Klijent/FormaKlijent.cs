﻿using Domen;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klijent
{
    public partial class FormaKlijent : Form
    {
        Komunikacija k;
        Izdanje i;

        public FormaKlijent()
        {
            InitializeComponent();
        }

        private void FormaKlijent_Load(object sender, EventArgs e)
        {
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "Unos izdanja - Klijentski program";
            }
            cmbPublikacija.DataSource = k.VratiSvePublikacije();
            
            i = new Izdanje();
            dataGridView1.DataSource = i.ListaVesti;
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            Publikacija p = new Publikacija();

            try
            {
                p = cmbPublikacija.SelectedItem as Publikacija;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali publikaciju!");
            }
            new DodajVest(k, i,p).ShowDialog();
        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {
            try
            {
                Vest v = dataGridView1.CurrentRow.DataBoundItem as Vest;
                i.ListaVesti.Remove(v);

                
                int s = 1;
                foreach (Vest vest in i.ListaVesti)
                {
                    vest.Rb = s;
                    s++;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali vest za brisanje!");
            }
        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {
            try
            {
                i.Datum = DateTime.ParseExact(txtDatum.Text, "dd.MM.yyyy", null);
                if (i.Datum == null)
                {
                    MessageBox.Show("Niste uneli datum!");
                    return;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Nije validan datum!");
                return;
            }
            try
            {
                i.Broj = Convert.ToInt32(txtBroj.Text);
                if (i.Broj == 0)
                {
                    MessageBox.Show("Niste uneli broj!");
                    return;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Niste uneli dobar broj izdanja!");
                return;
            }
            try
            {
                i.Publikacija = cmbPublikacija.SelectedItem as Publikacija;
            }
            catch (Exception)
            {
                MessageBox.Show("Niste odabrali publikaciju!");
                return;
            }
            if (i.ListaVesti.Count() < 1)
            {
                MessageBox.Show("Izdanje mora sadrzati bar jednu vest!");
                return;
            }

            if (k.SacuvajIzdanje(i))
            {
                MessageBox.Show("Uspesno cuvanje!");
            }
            else
            {
                MessageBox.Show("Neuspesno!");
            }
        }
    }
}
