﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class DodajVest : Form
    {
        private Komunikacija k;
        private Izdanje i;
        private Publikacija p;

        public DodajVest()
        {
            
        }

        public DodajVest(Komunikacija k, Izdanje i)
        {
            
        }

        public DodajVest(Komunikacija k, Izdanje i, Publikacija p) : this(k, i)
        {
            InitializeComponent();
            this.k = k;
            this.i = i;
            this.p = p;
        }

        private void DodajVest_Load(object sender, EventArgs e)
        {
            this.Text = p.Naziv;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Vest v = new Vest();

            v.Rb = i.ListaVesti.Count() + 1;

            v.Naslov = txtNaslov.Text;
            if (v.Naslov == "")
            {
                MessageBox.Show("Niste uneli naslov vesti!");
                return;
            }
            if (v.Naslov.Length > 100)
            {
                MessageBox.Show("Naslov sme imati najvise 100 karaktera");
                return;
            }
            v.Tekst = txtTekst.Text;
            if (v.Tekst == "")
            {
                MessageBox.Show("Niste uneli tekst vesti!");
                return;
            }

            v.Publikacija = p;

            i.ListaVesti.Add(v);

            this.Close();
        }
    }
}
