﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Vest
    {
        int rb;
        string naslov;
        string tekst;
        Publikacija publikacija;

        public Publikacija Publikacija { get => publikacija; set => publikacija = value; }
        public int Rb { get => rb; set => rb = value; }
        public string Naslov { get => naslov; set => naslov = value; }
        public string Tekst { get => tekst; set => tekst = value; }
        
    }
}
