﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Izdanje
    {
        int id;
        DateTime datum;
        int broj;
        Publikacija publikacija;
        BindingList<Vest> listaVesti;

        public Izdanje()
        {
            ListaVesti = new BindingList<Vest>();
        }

        public int Id { get => id; set => id = value; }
        public DateTime Datum { get => datum; set => datum = value; }
        public int Broj { get => broj; set => broj = value; }
        public Publikacija Publikacija { get => publikacija; set => publikacija = value; }
        public BindingList<Vest> ListaVesti { get => listaVesti; set => listaVesti = value; }

        //public BindingList<Izdanje> ListaIzdanja { get => listaIzdanja; set => listaIzdanja = value; }
    }
}
