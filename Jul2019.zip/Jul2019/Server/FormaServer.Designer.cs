﻿namespace Server
{
    partial class FormaServer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbFilete = new System.Windows.Forms.CheckBox();
            this.cmbZivotinja = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbFilete
            // 
            this.cmbFilete.AutoSize = true;
            this.cmbFilete.Location = new System.Drawing.Point(13, 25);
            this.cmbFilete.Name = "cmbFilete";
            this.cmbFilete.Size = new System.Drawing.Size(166, 21);
            this.cmbFilete.TabIndex = 0;
            this.cmbFilete.Text = "Filter po vrsti zivotinje";
            this.cmbFilete.UseVisualStyleBackColor = true;
            // 
            // cmbZivotinja
            // 
            this.cmbZivotinja.FormattingEnabled = true;
            this.cmbZivotinja.Location = new System.Drawing.Point(219, 23);
            this.cmbZivotinja.Name = "cmbZivotinja";
            this.cmbZivotinja.Size = new System.Drawing.Size(236, 24);
            this.cmbZivotinja.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 80);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(602, 249);
            this.dataGridView1.TabIndex = 2;
            // 
            // FormaServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 341);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.cmbZivotinja);
            this.Controls.Add(this.cmbFilete);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FormaServer";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FormaServer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox cmbFilete;
        private System.Windows.Forms.ComboBox cmbZivotinja;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

