﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Domen;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;

namespace Klijent
{
    public class Komunikacija
    {
        TcpClient klijent;
        NetworkStream tok;
        BinaryFormatter formater;

        public bool poveziSeNaServer()
        {
            try
            {
                klijent = new TcpClient("localhost",20000);
                tok = klijent.GetStream();
                formater = new BinaryFormatter();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public void kraj()
        {
            //slanje
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.Kraj;
            formater.Serialize(tok, transfer);
        }

        public Poljoprivrednik LogIn(Poljoprivrednik p)
        {
            //slanje
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.logIn;
            transfer.TransferObjekat = p;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat as Poljoprivrednik;
        }

        public int vratiSifru()
        {
            //slanje
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.vratiSifruGazdinstva;
            //transfer.TransferObjekat = p;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return (int)transfer.Rezultat;
        }

        public bool KreirajGazd(Gazdinstvo g)
        {
            //slanje
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.kreirajGazdinstvo;
            transfer.TransferObjekat = g;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return (bool)transfer.Rezultat;
        }

        public List<Zivotinja> vratiSveZivotinje()
        {
            //slanje
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.vratiSveZivotinje;
            //transfer.TransferObjekat = g;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Rezultat as List<Zivotinja>;
        }

        public bool SacuvajGazdinstvo(Gazdinstvo g)
        {
            //slanje
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.sacuvajGazdinstvo;
            transfer.TransferObjekat = g;
            formater.Serialize(tok, transfer);

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return (bool)transfer.Rezultat;
        }
    }
}
