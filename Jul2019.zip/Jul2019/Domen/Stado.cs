﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Stado
    {
        Gazdinstvo gazdinstvo;
        int id;
        int brojGrla;
        double iznosSubvencije;
        Zivotinja zivotinja;

        [Browsable(false)]
        public Gazdinstvo Gazdinstvo { get => gazdinstvo; set => gazdinstvo = value; }
        [Browsable(false)]
        public int Id { get => id; set => id = value; }
        public string Naziv => zivotinja.Naziv;
        public bool Autohtona => Zivotinja.AutohtonaVrsta;
        public double SubvencijaPoGrlu => Zivotinja.SubvencijaPoGrlu;
        public int BrojGrla { get => brojGrla; set => brojGrla = value; }
        public double IznosSubvencije { get => iznosSubvencije; set => iznosSubvencije = value; }
        //public BindingList<Zivotinja> ListaZivotinja { get => listaZivotinja; set => listaZivotinja = value; }
        [Browsable(false)]
        public Zivotinja Zivotinja { get => zivotinja; set => zivotinja = value; }
        
    }
}
