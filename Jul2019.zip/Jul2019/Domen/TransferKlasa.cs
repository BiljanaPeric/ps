﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    public enum Operacije { Kraj=1,
        logIn = 2,
        vratiSifruGazdinstva = 3,
        kreirajGazdinstvo = 4,
        vratiSveZivotinje = 5,
        sacuvajGazdinstvo = 6
    }

    [Serializable]
    public class TransferKlasa
    {
        public Operacije Operacija;
        public object TransferObjekat; //salje se
        public object Rezultat; //prima se
    }
}
