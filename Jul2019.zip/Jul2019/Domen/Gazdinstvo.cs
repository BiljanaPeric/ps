﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Gazdinstvo
    {
        int id;
        string naziv;
        DateTime datumRegistracije;
        double ukupnoSubvencija;
        Poljoprivrednik poljoprivrednik;
        BindingList<Stado> listaStada;

        public Gazdinstvo()
        {
            ListaStada = new BindingList<Stado>();
        }



        public int Id { get => id; set => id = value; }
        public string Naziv { get => naziv; set => naziv = value; }
        public DateTime DatumRegistracije { get => datumRegistracije; set => datumRegistracije = value; }
        public double UkupnoSubvencija { get => ukupnoSubvencija; set => ukupnoSubvencija = value; }
        
        public Poljoprivrednik Poljoprivrednik { get => poljoprivrednik; set => poljoprivrednik = value; }
        public BindingList<Stado> ListaStada { get => listaStada; set => listaStada = value; }

    }
}
